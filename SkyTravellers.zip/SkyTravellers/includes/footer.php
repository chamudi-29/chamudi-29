    </main>
        <footer>
            <div class="container">
                <div class="footer-links">
                    <a href="/skytravellers/pages/contact.php">Contact Us</a>
                    <a href="/skytravellers/pages/terms.php">Terms and Conditions</a>
                    <a href="/skytravellers/pages/privacy.php">Privacy and Policy</a>
                </div>
                <div class="social-icons">
                    <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                </div>
                <p>&copy; <?php echo date("Y"); ?> SkyTravellers. All rights reserved.</p>        
            </div>
        </footer>
        <script src="skytravellers/assets/js/script.js"></script>
    </body>
</html>