</div> <!-- Closing tag for admin-container -->
    <footer class="admin-footer">
        <div class="footer-content">
           <div class="footer-logo">
                <img src="/skytravellers/assets/images/large.png" alt="Sky Travellers Logo">
            </div>
            <div class="footer-links">
                <h3>Information</h3>
                <ul>
                    <li><a href="/terms.php">Terms & Conditions</a></li>
                    <li><a href="/privacy.php">Privacy Policy</a></li>
                    <li><a href="/faq.php">FAQs</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <h3>Contact Us</h3>
                <p>Email: abcde@gmail.com</p>
                <p>Phone: 0123456789</p>
            </div>
        </div>
        <div class="footer-social">
            <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-whatsapp"></i></a>
            <a href="#" class="social-icon"><i class="far fa-envelope"></i></a>
        </div>
        <div class="footer-copyright">
            <p>&copy; 2024 SkyTravellers, Inc. All rights reserved</p>
        </div>
    </footer>
    <script src="/skytravellers/assets/js/admin_scripts.js"></script>
</body>
</html>