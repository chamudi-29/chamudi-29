<?php



header('Location: pages/landing.php');