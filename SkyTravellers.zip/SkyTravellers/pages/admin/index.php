<?php

header('Location: airline_management.php');