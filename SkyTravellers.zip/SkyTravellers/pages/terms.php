<?php
$pageTitle = "Terms & Conditions - Sky Travellers";
include '../includes/header.php';
?>

<div class="container" style="margin: 4rem 7rem">
    <h1>Terms and Conditions</h1>
    <p>Welcome to Sky Travellers! By using our platform, you agree to comply with the following terms and conditions.</p>

    <h2>Booking and Payment</h2>
    <p>All bookings made through our platform are subject to the terms and conditions of the respective airlines. Payments are processed securely, and refunds are issued according to the airline's policies.</p>

    <h2>User Responsibilities</h2>
    <p>Users are responsible for providing accurate information when making bookings. Sky Travellers is not responsible for any issues arising from incorrect or incomplete information provided by users.</p>

    <h2>Cancellation and Refund Policy</h2>
    <p>Cancellations and refunds are subject to the terms of the airline and may incur additional charges. Please review the specific policies for your booking before confirming.</p>

    <h2>Limitation of Liability</h2>
    <p>Sky Travellers is not liable for any losses or damages incurred as a result of using our platform, except where required by law. We strive to provide accurate and reliable information, but we do not guarantee the completeness or accuracy of the data available on our site.</p>
</div>

<?php
include '../includes/footer.php';
?>
