<?php
$pageTitle = "Privacy Policy - Sky Travellers";
include '../includes/header.php';
?>

<div class="container" style="margin: 4rem 7rem">
    <h1>Privacy Policy</h1>
    <p>At Sky Travellers, we value your privacy and are committed to protecting your personal information. This Privacy Policy outlines how we collect, use, and protect the data you share with us when using our platform.</p>

    <h2>Information We Collect</h2>
    <p>We may collect personal information such as your name, email address, payment information, and travel preferences when you make a booking on our platform.</p>

    <h2>How We Use Your Information</h2>
    <p>The information we collect is used to process your bookings, improve our services, and ensure a smooth experience on our platform. We do not share your information with third parties without your consent, except where required by law.</p>

    <h2>Data Security</h2>
    <p>We take appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction.</p>

    <h2>Your Rights</h2>
    <p>You have the right to access, update, or delete your personal information at any time. Please contact us if you have any questions regarding your data or this policy.</p>
</div>

<?php
include '../includes/footer.php';
?>
