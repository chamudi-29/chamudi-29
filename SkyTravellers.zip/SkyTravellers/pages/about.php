<?php
$pageTitle = "About Us - Sky Travellers";
include '../includes/header.php';
?>

<!--<div class="container" style="margin: 4rem 7rem">
    <h1>About Sky Travellers</h1>
    <p>Welcome to Sky Travellers! We are a leading online platform providing easy and efficient flight booking services to customers worldwide. 
    Our mission is to make travel more accessible, affordable, and convenient for everyone.</p>

    <h2>Our Vision</h2>
    <p>We aim to be the most preferred flight booking platform by offering top-notch services and customer care, ensuring seamless travel experiences for all our users.</p>

    <h2>Our Team</h2>
    <p>We are a passionate team of travel enthusiasts and tech-savvy professionals committed to simplifying the way people travel. With years of experience in the travel industry, we understand the needs of modern-day travelers.</p>
</div>-->
<div class="container" style="margin: 4rem 7rem">
    <h1>About Us</h1>
    <div class="about-sections">
        <section class="mission">
            <div>
                <h2>Our Mission</h2>
                <p>Our aim search out evolve a tenable, favorable air aircraft carrier that supports general migrants, tourism, and the civil saving, while boosting Sri Lanka's singular position as an air transport hub in the Indian Ocean. We seek to give singular duty and develop ability for the aeronautics manufacturing, loyal to ethical trade practices that benefit two together the country and the societies we do. Our focus remains on enduring sustainability, guaranteeing that our air carrier provides positively to Sri Lanka’s worldwide concept while improving travel experiences for passengers from everywhere the experience.</p>
            </div>
            <img src="/skytravellers/assets/images/AB1.jpg"alt="Mission ">
        </section>

        <section class="who-we-are alternate">
            <div>
                <h2>Who We Are</h2>
                <p>We are an creative air carrier with a devoted effort to something joining the realm accompanying Sri Lanka, providing seamless travel happenings for all. As we touch evolve, we are dedicated to making air travel more accessible, adept, and pleasing for all-encompassing passengers.
                    What is an Airline Booking System?
                    An Airline Reservation System (ARS) is a inclusive platform that admits airlines to offer departure tickets through miscellaneous channels, permissive seamless engagement knowledge for consumers. ARS helps manage departure schedules, fares, and specifies critical physical-time modernizes on applicable seats, guaranteeing that passengers can book their flights surely, securely, and capably from some one the globe.</p>
            </div>
            <img src="/skytravellers/assets/images/AB2.jpg"alt="Who We Are image">
        </section>

        <section class="commitment">
            <div>
                <h2>Our Commitment To You</h2>
                <p>We are dedicated to providing a trustworthy and handy air carrier card reservation knowledge. Our whole admits airlines to accomplish seat availability, schedules, and fares accompanying adeptness, guaranteeing that passengers can approach real-occasion facts when engagement flights. Through this, we maintain a itemized record of stipulations (Passenger Name Records or PNRs) and path circulated tickets, ensuring veracity and availability. Our aim search out ensure that your engagement happening is smooth, fast, and secure, indicating our obligation to customer delight and functional superiority.
This rewriting incorporates the supplementary devote effort to something the Airline Reservation System and by virtue of what it embellishes booking and seat administration while claiming your company’s obligation to passengers and righteous business practices.</p>
            </div>
            
        </section>
      </div>
</div>


<?php
include '../includes/footer.php';
?>
